
CONTRIBUTING YOUR TRANSLATION

This plugin is ready for translation.

If you want to help translate this plugin, please visit the [translation page](https://translate.wordpress.org/projects/wp-plugins/social-media-buttons-toolbar), or use the POT file, that is included and placed in the "languages" folder, in order to create a translation files (*.po, *.mo). Just send the translation files (*.po, *.mo) to me at the arthurgareginyan@gmail.com and I will include the translation within the next plugin update.

Also you can use an existing PO file that placed in the "languages" folder, in order to make corrections.

Many of plugin users would be delighted if you share your translation with the community. Thanks for your contribution!